// This utility extracts text from various document formats

import { PDFExtract } from "pdf.js-extract"
import mammoth from "mammoth"

// Function to extract text from various file types
export async function extractTextFromFile(file: File): Promise<string> {
  const fileType = file.type
  const fileName = file.name.toLowerCase()

  // PDF extraction
  if (fileType === "application/pdf" || fileName.endsWith(".pdf")) {
    return extractTextFromPDF(file)
  }

  // Word document extraction (DOCX)
  if (
    fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    fileName.endsWith(".docx")
  ) {
    return extractTextFromDOCX(file)
  }

  // Word document extraction (DOC)
  if (fileType === "application/msword" || fileName.endsWith(".doc")) {
    // For older DOC files, we might need a different approach
    // For now, we'll inform the user that DOC files might not extract perfectly
    const text = await file.text()
    if (text.length < 100) {
      return (
        "Warning: DOC file format may not extract properly. Consider converting to DOCX for better results.\n\n" + text
      )
    }
    return text
  }

  // RTF extraction
  if (fileType === "text/rtf" || fileName.endsWith(".rtf")) {
    return extractTextFromRTF(file)
  }

  // HTML extraction
  if (fileType === "text/html" || fileName.endsWith(".html") || fileName.endsWith(".htm")) {
    return extractTextFromHTML(file)
  }

  // Default: treat as plain text
  return file.text()
}

// Extract text from PDF
async function extractTextFromPDF(file: File): Promise<string> {
  try {
    // Convert File to ArrayBuffer
    const arrayBuffer = await file.arrayBuffer()

    // Use pdf.js-extract to extract text
    const pdfExtract = new PDFExtract()
    const options = {} // default options

    const data = await pdfExtract.extractBuffer(Buffer.from(arrayBuffer), options)

    // Combine text from all pages
    let text = ""
    if (data && data.pages) {
      data.pages.forEach((page) => {
        if (page.content) {
          page.content.forEach((item) => {
            text += item.str + " "
          })
          text += "\n\n" // Add paragraph breaks between pages
        }
      })
    }

    return text.trim()
  } catch (error) {
    console.error("Error extracting text from PDF:", error)
    return `Error extracting text from PDF: ${error instanceof Error ? error.message : "Unknown error"}`
  }
}

// Extract text from DOCX
async function extractTextFromDOCX(file: File): Promise<string> {
  try {
    // Convert File to ArrayBuffer
    const arrayBuffer = await file.arrayBuffer()

    // Use mammoth to extract text
    const result = await mammoth.extractRawText({ arrayBuffer })
    return result.value
  } catch (error) {
    console.error("Error extracting text from DOCX:", error)
    return `Error extracting text from DOCX: ${error instanceof Error ? error.message : "Unknown error"}`
  }
}

// Extract text from RTF
async function extractTextFromRTF(file: File): Promise<string> {
  try {
    // RTF extraction is complex, for now we'll use a simple approach
    // that might not handle all RTF features
    const text = await file.text()

    // Basic RTF cleaning (remove RTF control sequences)
    const cleanedText = text.replace(/\\[a-z0-9]+/g, ' ')
                          .replace(/\{|\}/g, '')
                          .replace(/\\'/[0-9a-f]{2}/g, ' ')
                          .replace(/\\\n/g, '\n')
                          .replace(/ {2,}/g, ' ');

    return cleanedText.trim()
  } catch (error) {
    console.error("Error extracting text from RTF:", error)
    return `Error extracting text from RTF: ${error instanceof Error ? error.message : "Unknown error"}`
  }
}

// Extract text from HTML
async function extractTextFromHTML(file: File): Promise<string> {
  try {
    const html = await file.text()

    // Create a DOM parser
    const parser = new DOMParser()
    const doc = parser.parseFromString(html, "text/html")

    // Extract text content
    const text = doc.body.textContent || ""

    return text.trim()
  } catch (error) {
    console.error("Error extracting text from HTML:", error)
    return `Error extracting text from HTML: ${error instanceof Error ? error.message : "Unknown error"}`
  }
}

