"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { FileText, CheckCircle, AlertTriangle } from "lucide-react"

interface DocumentExtractionStatusProps {
  fileName: string
  fileType: string
  status: "extracting" | "success" | "error"
  progress: number
  message?: string
  wordCount?: number
}

export function DocumentExtractionStatus({
  fileName,
  fileType,
  status,
  progress,
  message,
  wordCount,
}: DocumentExtractionStatusProps) {
  const [showDetails, setShowDetails] = useState(false)

  useEffect(() => {
    if (status === "success") {
      const timer = setTimeout(() => {
        setShowDetails(false)
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [status])

  if (status === "extracting") {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-medium">Extracting content from {fileName}</p>
            </div>
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-muted-foreground">{message || "Reading document content..."}</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (status === "success") {
    return (
      <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
        <CardContent className="p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
            <span className="text-sm font-medium">
              Successfully extracted {wordCount} words from {fileName}
            </span>
          </div>
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
          >
            {showDetails ? "Hide details" : "Show details"}
          </button>
        </CardContent>
        {showDetails && (
          <CardContent className="pt-0 pb-3 px-3">
            <div className="text-xs text-muted-foreground">
              <p>File type: {fileType}</p>
              <p>Word count: {wordCount}</p>
              <p>Status: Content extracted successfully</p>
            </div>
          </CardContent>
        )}
      </Card>
    )
  }

  if (status === "error") {
    return (
      <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
        <CardContent className="p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
            <span className="text-sm font-medium">Error extracting content from {fileName}</span>
          </div>
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
          >
            {showDetails ? "Hide details" : "Show details"}
          </button>
        </CardContent>
        {showDetails && (
          <CardContent className="pt-0 pb-3 px-3">
            <div className="text-xs text-muted-foreground">
              <p>File type: {fileType}</p>
              <p>Error: {message}</p>
              <p>Try converting the document to a different format or check if it's password protected.</p>
            </div>
          </CardContent>
        )}
      </Card>
    )
  }

  return null
}

