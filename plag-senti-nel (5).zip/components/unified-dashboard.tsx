"use client"

import { Badge } from "@/components/ui/badge"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import {
  FileCheck,
  Music,
  RefreshCcw,
  BookOpen,
  FileText,
  PenTool,
  FileSearch,
  BarChart3,
  Settings,
  History,
  Zap,
  BookMarked,
  Clock,
  TrendingUp,
  Award,
  Calendar,
  Users,
  Star,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { Progress } from "@/components/ui/progress"

export default function UnifiedDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const router = useRouter()

  const tools = [
    {
      id: "plagiarism-checker",
      name: "Document Plagiarism",
      description: "Scan documents for plagiarized content",
      icon: FileCheck,
      color: "text-green-500",
      path: "/tool/plagiarism-checker",
      usageCount: 124,
      lastUsed: "2 hours ago",
      averageTime: "3m 45s",
    },
    {
      id: "music-plagiarism",
      name: "Music Plagiarism",
      description: "Analyze audio files for copyright infringement",
      icon: Music,
      color: "text-purple-500",
      path: "/tool/music-plagiarism",
      usageCount: 56,
      lastUsed: "Yesterday",
      averageTime: "5m 20s",
    },
    {
      id: "paraphrasing",
      name: "Paraphrasing Tool",
      description: "Rewrite content while preserving meaning",
      icon: RefreshCcw,
      color: "text-indigo-500",
      path: "/tool/paraphrasing",
      usageCount: 215,
      lastUsed: "3 hours ago",
      averageTime: "2m 10s",
    },
    {
      id: "story-generator",
      name: "Story Generator",
      description: "Create original narratives with AI",
      icon: BookOpen,
      color: "text-yellow-500",
      path: "/tool/story-generator",
      usageCount: 78,
      lastUsed: "4 days ago",
      averageTime: "4m 15s",
    },
    {
      id: "text-summarizer",
      name: "Text Summarizer",
      description: "Generate concise summaries of long texts",
      icon: FileText,
      color: "text-orange-500",
      path: "/tool/text-summarizer",
      usageCount: 189,
      lastUsed: "1 day ago",
      averageTime: "1m 50s",
    },
    {
      id: "ai-essay-writer",
      name: "AI Essay Writer",
      description: "Generate well-structured essays on any topic",
      icon: PenTool,
      color: "text-pink-500",
      path: "/tool/ai-essay-writer",
      usageCount: 92,
      lastUsed: "5 days ago",
      averageTime: "6m 30s",
    },
    {
      id: "extract-text",
      name: "Extract Text",
      description: "Extract text from images with OCR",
      icon: FileSearch,
      color: "text-cyan-500",
      path: "/tool/extract-text",
      usageCount: 67,
      lastUsed: "2 days ago",
      averageTime: "1m 15s",
    },
  ]

  const recentActivity = [
    { id: 1, tool: "Document Plagiarism", date: "2 hours ago", result: "12% similarity", duration: "3m 12s" },
    { id: 2, tool: "Music Plagiarism", date: "Yesterday", result: "No matches found", duration: "4m 45s" },
    { id: 3, tool: "AI Essay Writer", date: "3 days ago", result: "Essay generated", duration: "5m 30s" },
    { id: 4, tool: "Extract Text", date: "1 week ago", result: "98% accuracy", duration: "1m 20s" },
    { id: 5, tool: "Paraphrasing Tool", date: "4 hours ago", result: "Content rewritten", duration: "2m 15s" },
    { id: 6, tool: "Text Summarizer", date: "2 days ago", result: "Summary created", duration: "1m 40s" },
  ]

  // Monthly usage data for charts
  const monthlyUsage = [
    { month: "Jan", scans: 45 },
    { month: "Feb", scans: 62 },
    { month: "Mar", scans: 78 },
    { month: "Apr", scans: 95 },
    { month: "May", scans: 110 },
    { month: "Jun", scans: 132 },
    { month: "Jul", scans: 145 },
    { month: "Aug", scans: 155 },
    { month: "Sep", scans: 180 },
    { month: "Oct", scans: 210 },
    { month: "Nov", scans: 248 },
    { month: "Dec", scans: 0 },
  ]

  // Calculate total usage statistics
  const totalScans = tools.reduce((acc, tool) => acc + tool.usageCount, 0)
  const mostUsedTool = tools.reduce((prev, current) => (prev.usageCount > current.usageCount ? prev : current))
  const averageTimePerScan =
    tools.reduce((acc, tool) => {
      const timeInSeconds =
        Number.parseInt(tool.averageTime.split("m")[0]) * 60 +
        Number.parseInt(tool.averageTime.split("m")[1].split("s")[0])
      return acc + timeInSeconds * tool.usageCount
    }, 0) / totalScans

  // Format average time
  const formatTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60)
    const seconds = Math.floor(timeInSeconds % 60)
    return `${minutes}m ${seconds}s`
  }

  return (
    <div className="container py-8 max-w-7xl mx-auto">
      <div className="flex flex-col gap-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Plagiarism Detection Suite</h1>
            <p className="text-muted-foreground">Advanced tools for content originality and creation</p>
          </div>
          <div className="flex gap-4">
            <Button variant="outline" className="gap-2">
              <History className="h-4 w-4" />
              History
            </Button>
            <Button variant="outline" className="gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </Button>
            <Button className="gap-2">
              <Zap className="h-4 w-4" />
              New Analysis
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tools">Tools</TabsTrigger>
            <TabsTrigger value="activity">Recent Activity</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Scans</CardTitle>
                  <FileCheck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalScans}</div>
                  <p className="text-xs text-muted-foreground">+12% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Similarity</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">18.2%</div>
                  <p className="text-xs text-muted-foreground">-3.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Content Created</CardTitle>
                  <BookMarked className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">36</div>
                  <p className="text-xs text-muted-foreground">+8% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Accuracy Rate</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">98.5%</div>
                  <p className="text-xs text-muted-foreground">+0.5% from last month</p>
                </CardContent>
              </Card>
            </div>

            {/* New Usage Statistics Section */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Most Used Tool</CardTitle>
                  <Star className="h-4 w-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-bold">{mostUsedTool.name}</div>
                  <p className="text-xs text-muted-foreground">{mostUsedTool.usageCount} uses</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Time per Scan</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-bold">{formatTime(averageTimePerScan)}</div>
                  <p className="text-xs text-muted-foreground">Across all tools</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-bold">24</div>
                  <p className="text-xs text-muted-foreground">+3 from last week</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Trend</CardTitle>
                  <TrendingUp className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-bold">+18.3%</div>
                  <p className="text-xs text-muted-foreground">Usage growth</p>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Usage Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Usage</CardTitle>
                <CardDescription>Number of scans performed each month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] w-full">
                  <div className="flex h-full items-end gap-2">
                    {monthlyUsage.map((month) => (
                      <div key={month.month} className="relative flex h-full w-full flex-col justify-end">
                        <div
                          className="bg-primary rounded-t-md w-full"
                          style={{ height: `${(month.scans / 250) * 100}%` }}
                        ></div>
                        <span className="absolute bottom-0 left-0 right-0 text-xs text-center -mb-6">
                          {month.month}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <h2 className="text-xl font-semibold mt-6">Quick Access</h2>
            <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
              {tools.slice(0, 4).map((tool) => (
                <Card
                  key={tool.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => router.push(tool.path)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center space-y-2">
                      <tool.icon className={`h-8 w-8 ${tool.color}`} />
                      <CardTitle className="text-lg">{tool.name}</CardTitle>
                      <CardDescription>{tool.description}</CardDescription>
                      <div className="text-xs text-muted-foreground mt-2">
                        Used {tool.usageCount} times • Last: {tool.lastUsed}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setActiveTab("tools")}>
                View All Tools
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="tools" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
              {tools.map((tool) => (
                <Card
                  key={tool.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => router.push(tool.path)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center space-y-2">
                      <tool.icon className={`h-8 w-8 ${tool.color}`} />
                      <CardTitle className="text-lg">{tool.name}</CardTitle>
                      <CardDescription>{tool.description}</CardDescription>
                      <div className="flex justify-between w-full text-xs text-muted-foreground mt-2">
                        <span>Used {tool.usageCount} times</span>
                        <span>Avg: {tool.averageTime}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your recent scans and content creation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">{activity.tool}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{activity.date}</span>
                          <span>•</span>
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {activity.duration}
                          </span>
                        </div>
                      </div>
                      <div>
                        <Badge variant="outline">{activity.result}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Saved Reports</CardTitle>
                <CardDescription>Access your saved analysis reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No saved reports yet</p>
                  <Button className="mt-4">Create New Report</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Tool Usage Distribution</CardTitle>
                  <CardDescription>Breakdown of tool usage by percentage</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {tools.map((tool) => {
                      const percentage = (tool.usageCount / totalScans) * 100
                      return (
                        <div key={tool.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <tool.icon className={`h-4 w-4 ${tool.color} mr-2`} />
                              <span>{tool.name}</span>
                            </div>
                            <span className="text-sm">{percentage.toFixed(1)}%</span>
                          </div>
                          <Progress value={percentage} className="h-2" />
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Usage Metrics</CardTitle>
                  <CardDescription>Performance and efficiency metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Average Processing Time</span>
                        <span className="text-sm font-medium">{formatTime(averageTimePerScan)}</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">System Accuracy</span>
                        <span className="text-sm font-medium">98.5%</span>
                      </div>
                      <Progress value={98.5} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">User Satisfaction</span>
                        <span className="text-sm font-medium">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">API Performance</span>
                        <span className="text-sm font-medium">96.3%</span>
                      </div>
                      <Progress value={96.3} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Usage Timeline</CardTitle>
                <CardDescription>Daily activity over the past 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] w-full">
                  <div className="flex h-full items-end gap-1">
                    {Array.from({ length: 30 }, (_, i) => {
                      const value = Math.floor(Math.random() * 20) + 1
                      return (
                        <div key={i} className="relative flex h-full w-full flex-col justify-end">
                          <div
                            className="bg-primary/80 hover:bg-primary rounded-t-sm w-full transition-all"
                            style={{ height: `${(value / 20) * 100}%` }}
                          ></div>
                        </div>
                      )
                    })}
                  </div>
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>30 days ago</span>
                  <span>Today</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Achievement Badges</CardTitle>
                <CardDescription>Milestones reached in your usage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex flex-col items-center p-4 border rounded-lg">
                    <Award className="h-8 w-8 text-yellow-500 mb-2" />
                    <span className="font-medium text-sm">Power User</span>
                    <span className="text-xs text-muted-foreground">100+ scans</span>
                  </div>
                  <div className="flex flex-col items-center p-4 border rounded-lg">
                    <Calendar className="h-8 w-8 text-blue-500 mb-2" />
                    <span className="font-medium text-sm">30-Day Streak</span>
                    <span className="text-xs text-muted-foreground">Consistent usage</span>
                  </div>
                  <div className="flex flex-col items-center p-4 border rounded-lg">
                    <FileCheck className="h-8 w-8 text-green-500 mb-2" />
                    <span className="font-medium text-sm">Accuracy Master</span>
                    <span className="text-xs text-muted-foreground">95%+ accuracy</span>
                  </div>
                  <div className="flex flex-col items-center p-4 border rounded-lg">
                    <TrendingUp className="h-8 w-8 text-purple-500 mb-2" />
                    <span className="font-medium text-sm">Growth Champion</span>
                    <span className="text-xs text-muted-foreground">10x monthly increase</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

