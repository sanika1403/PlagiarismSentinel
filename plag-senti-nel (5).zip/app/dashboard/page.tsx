"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import { BarChart, FileText, LogOut, Music, PieChart, Clock, TrendingUp } from "lucide-react"
import AnimatedBackground from "@/components/animated-background"
import { Progress } from "@/components/ui/progress"

interface UserData {
  username: string
  name: string
}

export default function Dashboard() {
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const checkAuth = () => {
      const storedUser = localStorage.getItem("user") || sessionStorage.getItem("user")

      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser)
          setUserData(parsedUser)
        } catch (error) {
          console.error("Failed to parse user data:", error)
          handleLogout()
        }
      } else {
        // Redirect to login if no user data found
        router.push("/login")
      }

      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const handleLogout = () => {
    // Clear user data from storage
    localStorage.removeItem("user")
    sessionStorage.removeItem("user")

    toast.success("You have been logged out successfully")
    router.push("/login")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  // Mock statistics data
  const stats = {
    documentsScanned: 24,
    plagiarismDetected: 7,
    musicAnalyzed: 12,
    averageSimilarity: 18.5,
  }

  // Tool usage data
  const toolUsage = [
    { name: "Document Plagiarism", count: 124, percentage: 45 },
    { name: "Music Plagiarism", count: 56, percentage: 20 },
    { name: "Paraphrasing Tool", count: 42, percentage: 15 },
    { name: "Text Summarizer", count: 35, percentage: 12 },
    { name: "AI Essay Writer", count: 22, percentage: 8 },
  ]

  // Time spent data
  const timeSpent = [
    { name: "Document Plagiarism", time: "3h 45m", averagePerUse: "1m 49s" },
    { name: "Music Plagiarism", time: "2h 10m", averagePerUse: "2m 19s" },
    { name: "Paraphrasing Tool", time: "1h 35m", averagePerUse: "2m 15s" },
    { name: "Text Summarizer", time: "55m", averagePerUse: "1m 34s" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <AnimatedBackground variant="grid" intensity="light" color="#6366f1" />

      <div className="container py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Welcome, {userData?.name || "User"}!</h1>
            <p className="text-muted-foreground">Here's an overview of your plagiarism detection activities</p>
          </div>

          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Documents Scanned</CardDescription>
              <CardTitle className="text-3xl">{stats.documentsScanned}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                <FileText className="inline h-4 w-4 mr-1" />
                Last 30 days
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Plagiarism Detected</CardDescription>
              <CardTitle className="text-3xl">{stats.plagiarismDetected}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                <PieChart className="inline h-4 w-4 mr-1" />
                {Math.round((stats.plagiarismDetected / stats.documentsScanned) * 100)}% of scanned documents
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Music Files Analyzed</CardDescription>
              <CardTitle className="text-3xl">{stats.musicAnalyzed}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                <Music className="inline h-4 w-4 mr-1" />
                Last 30 days
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Average Similarity</CardDescription>
              <CardTitle className="text-3xl">{stats.averageSimilarity}%</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                <BarChart className="inline h-4 w-4 mr-1" />
                Across all documents
              </div>
            </CardContent>
          </Card>
        </div>

        {/* New section: Tool Usage Statistics */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Tool Usage Statistics</h2>
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {toolUsage.map((tool) => (
                  <div key={tool.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>{tool.name}</span>
                      <span className="text-sm font-medium">
                        {tool.count} uses ({tool.percentage}%)
                      </span>
                    </div>
                    <Progress value={tool.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* New section: Time Spent Analysis */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Time Spent Analysis</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Total Time by Tool</CardTitle>
                <CardDescription>How much time you've spent using each tool</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {timeSpent.map((tool) => (
                    <div key={tool.name} className="flex items-center justify-between p-2 border-b">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{tool.name}</span>
                      </div>
                      <div className="font-medium">{tool.time}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Usage Efficiency</CardTitle>
                <CardDescription>Average time spent per tool use</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {timeSpent.map((tool) => (
                    <div key={tool.name} className="flex items-center justify-between p-2 border-b">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <span>{tool.name}</span>
                      </div>
                      <div className="font-medium">{tool.averagePerUse}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Monthly Activity Calendar */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Monthly Activity</h2>
          <Card>
            <CardHeader>
              <CardTitle>Activity Heatmap</CardTitle>
              <CardDescription>Your usage patterns over the past month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {Array.from({ length: 30 }, (_, i) => {
                  const intensity = Math.floor(Math.random() * 5)
                  return (
                    <div
                      key={i}
                      className={`aspect-square rounded-sm border ${
                        intensity === 0
                          ? "bg-muted"
                          : intensity === 1
                            ? "bg-green-100"
                            : intensity === 2
                              ? "bg-green-200"
                              : intensity === 3
                                ? "bg-green-300"
                                : "bg-green-400"
                      }`}
                      title={`${intensity} scans on day ${i + 1}`}
                    />
                  )
                })}
              </div>
              <div className="flex justify-end items-center gap-2 mt-4 text-xs text-muted-foreground">
                <span>Less</span>
                <div className="bg-muted w-3 h-3 rounded-sm border"></div>
                <div className="bg-green-100 w-3 h-3 rounded-sm border"></div>
                <div className="bg-green-200 w-3 h-3 rounded-sm border"></div>
                <div className="bg-green-300 w-3 h-3 rounded-sm border"></div>
                <div className="bg-green-400 w-3 h-3 rounded-sm border"></div>
                <span>More</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

