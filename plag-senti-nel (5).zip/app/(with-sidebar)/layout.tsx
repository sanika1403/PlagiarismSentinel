import type React from "react"
export default function WithSidebarLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative min-h-screen">
      {/* Main Content */}
      <div className="w-full">{children}</div>
    </div>
  )
}

